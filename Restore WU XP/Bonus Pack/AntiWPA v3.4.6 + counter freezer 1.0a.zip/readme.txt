                                           
Version 3.4.7 was made for 2003 server X64 with Service Pack 2
--------------------------------------------------------------------
Also works for 32 bit versions and XP64 


** CW2K and HLT are the authors **

What the patch modifies:
   * HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon\Notify\AntiWPA
     is added to Registry

   * File C:\windows\system32\AntiWPA.dll is added


   * HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\WPAEvents]
     data for "OOBETimer" is changed {=OOBE}

   * rundll32 setupapi,InstallHinfSection DEL_OOBE_ACTIVATE 132 syssetup.inf
     rundll32 setupapi,InstallHinfSection RESTORE_OOBE_ACTIVATE 132 syssetup.inf
     is executed which will remove/restore WPA-links from the startmenu

How it works:

It tricks winlogon.exe to make it believe it was booted in safemode,thus, winlogon skips
the WPA-Check. The trick is done by redirecting(=hooking) the windows function
(user32.dll!GetSystemMetrics(SM_CLEANBOOT{=0x43}) & ntdll.dll!NtLockProductActivation)
 in memory to antiwpa.dll so winlogon 'thinks' was booted in safemode.
*Note (...because some ppl were concered about): The patch do not alter any
files on harddisk nor the hooks affects any other exe or dll in memory than
winlogon.exe.

The patch auto-runs on each start before the WPA-check via:
HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon\Notify\AntiWPA

The hooks are applied when AntiWPA.dll!onLogon is called by winlogon.exe.
The Winlogon.exe file on the harddisk is not altered anymore.
Patching (API-Hooking) is done in memory, so there are no problems with
Windows System File Protection.

Installation is performed via AntiWPA.dll!DllRegisterServer ("regsvr32 AntiWPA.dll").
The file is copied to systemdir and the registrykeys are added.
(Note: AntiWPA.dll is no ActiveX selfregisterdll.)
Uninstallation is done via AntiWPA.dll!DllUnRegisterServer ("regsvr32 -u AntiWPA.dll").

AntiWPA.dll was done by
<CW2K>

counterfreezer Explanation:
--------------------------------------------------------
The patch will deny permissions of 'system' to write to
"HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\WPAEvents"
That regkey is used by msoobe and sysinfo and other programs to get
activation status. And if it's read-only the wpa-call inside winlogon 
will not be able to set the activation status. But the wpa-call don't
uses the key to get how many days left(it gets that info elsewhere) so
It won't stop the internal activation counter.

Why this patch is is needed? The wpa-function is called from two locations in winlogon the 
major one is called at login. If antiwpa3 is running winlogon will thinks it's in safe mode 
and will skip it. The other from winlogon message loop which will actualise the days counter 
every 1-8 hours. Normally that timer is not installed if it's in safe mode or if it is already 
activated. But for some reason in Win2k3 the WPA-function is called from this second location 
and makes the counter to continue. Antiwpa2 patch patches directly the WPA-function and makes 
that it is not executed at all and to return always true. So it does matter from how many location 
if it is called and since it is not executed it would update the activation counter. So that's 
why it seems that only antiwpa2 works for win2k3.

To summarize it antiwpa2 patches the WPA-function inside winlogon directly while Antiwpa3 just 
prevents its call (especially the first one). The major thing is that the first WPA-function call 
is prevented so you will be allowed to login. Both antiwpa2 & antiwpa3 will do this. 




