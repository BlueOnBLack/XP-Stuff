#pragma once

typedef LONG NTSTATUS;
