/*----------------------------------------------------------------------
"Debugging Applications" (Microsoft Press)
Copyright (c) 1997-2000 John Robbins -- All rights reserved.
----------------------------------------------------------------------*/

#include "WarningsOff.h"
#include <windows.h>
#include <stdlib.h>
#include <tchar.h>
#include <PSAPI.h>
#include <process.h>

// STL will not compile at /W4 /WX.  Not good.
#ifndef _DEBUG
// function '' not inlined
#pragma warning ( disable : 4710 )
#endif
#pragma warning( push, 3 )

#ifdef __cplusplus
	#include <vector>
	using namespace std ;
#endif

#pragma warning( pop )
