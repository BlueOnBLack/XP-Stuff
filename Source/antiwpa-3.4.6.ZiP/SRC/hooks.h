#pragma once

#define SETIMPHOOK(dll,imp) SetHook(( PROC*)&my_##imp,  _T(#dll".DLL"),  _T(#imp), (PROC*) &old_##imp)

NTSTATUS
(_stdcall *
old_\
NtLockProductActivationKeys)(
							 IN PULONG64 privateId, 
							 IN PBOOL fSafeMode
							 );

int
(_stdcall*
old_\
GetSystemMetrics)(
				  IN int nIndex
				  );

NTSTATUS
_stdcall 
my_\
NtLockProductActivationKeys(
							IN PULONG64 privateId, 
							IN PBOOL fSafeMode
							);

int
_stdcall
my_\
GetSystemMetrics(
				 IN int nIndex
				 );


