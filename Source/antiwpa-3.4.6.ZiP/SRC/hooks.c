#include "project.h"
// #define SM_STARTER = 0x58

NTSTATUS
_stdcall 
my_\
NtLockProductActivationKeys(
							IN PULONG64 privateId, 
							IN PBOOL fSafeMode
							)
{
	//  the arg 'privateId' is initialised with the good values
	//  so there is no need to call old_NtLockProductActivationKeys
	//  to set it.

	//	NTSTATUS status = old_NtLockProductActivationKeys(privateId, fSafeMode);
	NTSTATUS status = 0;

	if(fEnabled)
		*fSafeMode = TRUE;
	return status;
}


int
_stdcall
my_\
GetSystemMetrics(
				 IN int nIndex
				 )
{
	if (fEnabled)
		switch (nIndex) {
			case SM_CLEANBOOT:
				return 1;
				break;
//			case 68://SM_STARTER:
//				return 0;
		};



	return old_GetSystemMetrics(nIndex);
}


