#include "project.h"

BOOL DelFileWithWildcards(LPCSTR Filename) {

	WIN32_FIND_DATA FileData; 
	HANDLE hSearch; 
//	TCHAR Path[MAX_PATH];
	TCHAR FName[MAX_PATH];
	TCHAR tmpName[MAX_PATH];
	BOOL RetVal=TRUE;

/*
	SHFILEOPSTRUCT sfo;
	    sfo.hwnd = NULL;
	    sfo.wFunc = FO_DELETE;
	    sfo.pFrom = tmpName;
		sfo.fFlags = FOF_SILENT | FOF_NOCONFIRMATION | FOF_NOCONFIRMMKDIR;

		sfo.pTo=tmpName;
//		sfo.fAnyOperationsAborted = 0;
//		sfo.hNameMappings =0;
    
		SHFileOperation(&sfo);
		*/
		// Start searching for Antiwpa.dll_* 
		StringCchCopy(FName, MAX_PATH, Filename);
		hSearch = FindFirstFile(FName, &FileData); 
		if (hSearch != INVALID_HANDLE_VALUE) 		{ 
		
			//Get path (make  FName = "c:\WINXP\SYSTEM32\" )
			PathRemoveFileSpec(FName); PathAddBackslash(FName);

			// Delete each Antiwpa.dll_*
			do	{ 
			// DeleteFile(FName & FileData.cFileName)				
				StringCbPrintf(tmpName, MAX_PATH, _T("%s%s"), FName, FileData.cFileName);
				RetVal &=  DeleteFile(tmpName);
			} while ( FindNextFile( hSearch, &FileData) ) ;
		}

		// Close the search handle. 
		FindClose(hSearch);
		return (RetVal);
	
}


///////////////////////////////////
// getFileNames
HRESULT
getFileNames(
			 IN PTCHAR oldName,
			 IN PTCHAR newName,
			 IN PTCHAR fileName
			 )
{
	HRESULT hr = S_OK;
	
	// Get Current Name
	if(GetModuleFileName(g_hinstDll, oldName, MAX_PATH*sizeof(TCHAR)) == 0) {
		hr = E_UNEXPECTED;
	}
	if(SUCCEEDED(hr)) {
		hr = StringCchCopy(fileName, MAX_PATH, oldName);
	}
	
	// Get Windows/system32 Dir
	if(SUCCEEDED(hr)) {
		PathStripPath(fileName);
		if(GetSystemDirectory(newName, MAX_PATH * sizeof(TCHAR)) == 0)
			hr = E_UNEXPECTED;
	}
	if(SUCCEEDED(hr)) {
		if(
			!PathAppend(newName, fileName))
			hr = E_UNEXPECTED;
	}
	return hr;
}

///////////////////////////////////
// updateRegistry
HRESULT
updateRegistry(
			   IN PTCHAR dllName,
			   IN BOOL fDelete
			   )
{
	HKEY hOurKey;
	ULONG dwZero=0;
	TCHAR fnName[] = _T("onLogon");
	PTCHAR ourKeyName = 
		_T("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Winlogon\\Notify\\Antiwpa");
	if(fDelete) {
		RegDeleteKey(HKEY_LOCAL_MACHINE, ourKeyName);
		return S_OK;
	}
	if(RegCreateKeyEx(
		HKEY_LOCAL_MACHINE, 
		ourKeyName, 
		0, 
		NULL, 
		0, 
		KEY_ALL_ACCESS, 
		NULL, 
		&hOurKey,
		NULL) != 
		ERROR_SUCCESS)
	{
		return E_UNEXPECTED;
	}
	RegSetValueEx(hOurKey, _T("Impersonate"), 0, REG_DWORD, (PBYTE)&dwZero, sizeof(dwZero));
	RegSetValueEx(hOurKey, _T("Asynchronous"), 0, REG_DWORD, (PBYTE)&dwZero, sizeof(dwZero));
	RegSetValueEx(hOurKey, _T("DllName"), 0, REG_SZ, (PBYTE)dllName, (lstrlen(dllName) + 1) * sizeof(TCHAR));
	RegSetValueEx(hOurKey, _T("Logon"), 0, REG_SZ, (PBYTE)fnName, sizeof(fnName));
	return S_OK;
}

///////////////////////////////////
// updateFiles
/*	install
		ren system32\antiwpa.dll -> antiwpa.dll_123
		del system32\antiwpa.dll*
		copy antiwpa.dll -> system32\antiwpa.dll


	uninstall
		ren system32\antiwpa.dll -> antiwpa.dll_123
		del system32\antiwpa.dll*

*/
HRESULT
updateFiles(
			IN PTCHAR oldName,
			IN PTCHAR newName,
			IN BOOL fUnreg
			)
{
	// Init result
	HRESULT hr = S_OK;

	// if old and new fileName is not the same
	if (lstrcmpi(oldName, newName)) {


		//ren system32\antiwpa.dll -> antiwpa.dll_123
		TCHAR tmpName[MAX_PATH];
		StringCbPrintf(tmpName, MAX_PATH, _T("%s_%X"), newName, GetTickCount());
		MoveFile(newName, tmpName);


		// del system32\antiwpa.dll*
		hr = StringCbPrintf(tmpName, MAX_PATH, _T("%s*"), newName);
		DelFileWithWildcards(tmpName);

		// on installation: copy antiwpa.dll -> system32\antiwpa.dll
		if(!fUnreg) 
			if( !CopyFile( oldName, newName, FALSE ) ) {

				StringCbPrintf(tmpName, MAX_PATH, _T("Copying %s to %s failed! Errorcode: %X"), 
							   newName, oldName, HRESULT_FROM_WIN32(GetLastError()));

				MessageBox ( GetForegroundWindow ( )       ,
							 tmpName                       ,    
							"Antiwpa3 - Filecopy Error"    ,
							MB_ICONERROR                    ) ;

			}


//------------

/*					
	if(fUnreg || !inPlace) {	
		if(!DeleteFile(newName) && (GetLastError() != ERROR_FILE_NOT_FOUND)) {
			TCHAR tmpName[MAX_PATH];
			hr = StringCbPrintf(tmpName, MAX_PATH, _T("%s%X"), newName, GetTickCount());
			if(SUCCEEDED(hr) && !MoveFile(newName, tmpName))
				hr = HRESULT_FROM_WIN32(GetLastError());
		}
	}
	if(!(fUnreg || inPlace)) {
		if(!CopyFile(oldName, newName, FALSE))
			hr = HRESULT_FROM_WIN32(GetLastError());
		}*/
	} //strcmp
	return hr;
}
	
///////////////////////////////////
// OOBERegistryFix
const unsigned char OOBEData[12] = {
	0x7F, 0x63, 0x3E, 0xBE, 0xEC, 0x25, 0x8E, 0x19, 0xBE, 0xA7, 0x92, 0xC6};


HRESULT
OOBERegistryFix( IN BOOL fDelete)
{
	HKEY hOurKey;
	TCHAR fnName[] = _T("OOBETimer");
	PTCHAR ourKeyName = 
		_T("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\WPAEvents");


/*	if(fDelete) {
		RegDeleteKey(HKEY_LOCAL_MACHINE, ourKeyName);
		return S_OK;
	}
*/
	if(RegCreateKeyEx(
		HKEY_LOCAL_MACHINE, ourKeyName, 0, NULL, 0, 
		KEY_ALL_ACCESS, NULL, &hOurKey,NULL)		!= ERROR_SUCCESS)
	{
		return E_UNEXPECTED;
	}
	RegSetValueEx(hOurKey, _T("OOBETimer"), 0, REG_BINARY, OOBEData, 
		(fDelete)? 0 : sizeof(OOBEData));
	return S_OK;
}

///////////////////////////////////
// DeleteRestoreWPALinks
HRESULT
DeleteRestoreWPALinks ( IN BOOL fDelete)
{
	ShellExecute(0,_T("open"),_T("rundll32"),
		fDelete? _T("setupapi,InstallHinfSection RESTORE_OOBE_ACTIVATE 132 syssetup.inf"):
				 _T("setupapi,InstallHinfSection DEL_OOBE_ACTIVATE 132 syssetup.inf"),
				 0,SW_HIDE
	);
	return S_OK;
}

///////////////////////////////////
// dllRegUnreg
HRESULT 
dllRegUnreg(
			IN BOOL fUnreg
			)
{
	HRESULT hr = S_OK;
	TCHAR oldName[MAX_PATH];
	TCHAR newName[MAX_PATH];
	TCHAR fileName[MAX_PATH];
	hr = getFileNames(oldName, newName, fileName);
	if(SUCCEEDED(hr)) {
		hr = updateRegistry(fileName, fUnreg);
	}
	if(SUCCEEDED(hr)) {
		hr = updateFiles(oldName, newName, fUnreg);
	}

	if(SUCCEEDED(hr)) {
		hr = OOBERegistryFix(fUnreg);
	}

	if(SUCCEEDED(hr)) {
		hr = DeleteRestoreWPALinks(fUnreg);
	}
	return hr;
}

///////////////////////////////////
// DllRegisterServer
STDAPI
DllRegisterServer()
{
	return dllRegUnreg(FALSE);
}


///////////////////////////////////
// DllUnregisterServer
STDAPI
DllUnregisterServer()
{
	return dllRegUnreg(TRUE);
}