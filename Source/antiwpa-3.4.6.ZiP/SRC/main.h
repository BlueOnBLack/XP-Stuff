#pragma once

 extern BOOL fEnabled;
 extern HINSTANCE g_hinstDll;