#pragma once

#ifdef UNICODE
#ifndef _UNICODE
#define _UNICODE
#endif	//_UNICODE
#endif	//UNICODE

#include <stdio.h>

#include <windows.h>
#include <tchar.h>
#include <shlwapi.h>
#include <strsafe.h>

#include "types.h"
#include "hooks.h"
#include "main.h"
#include "BugslayerUtil.h"