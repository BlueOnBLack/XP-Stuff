#include "project.h"
//#define BREAK_ON_LOAD

HINSTANCE g_hinstDll = NULL;
BOOL fEnabled = FALSE;



BOOL  SetHook ( PROC *          pMyNewFuncs ,				
				LPCSTR          szImportMod ,	
			    LPCSTR			szFunc		,
                PROC *          pOutOrigFuncs )
{// VAR
//	DWORD uiCount ;
    HOOKFUNCDESC stToHook ;

// Begin
	stToHook.szFunc = szFunc ;
	stToHook.pProc  = (PROC)pMyNewFuncs; 
    
    return(	HookImportedFunctionsByName (
				GetModuleHandle ( NULL ), szImportMod , 1 ,
				&stToHook, (PROC*)pOutOrigFuncs, NULL			)
	);
}

void
sethooks()
{
	#ifdef BREAK_ON_LOAD
		DebugBreak();
	#endif	//DEBUG

//  SetHook(( PROC*)&my_##imp,  _T(#dll".DLL"),  _T(#imp), (PROC*) &old_##imp)
	if(!GetSystemMetrics(SM_CLEANBOOT)) {
		fEnabled = 
		SETIMPHOOK(user32, GetSystemMetrics) &&
		SETIMPHOOK(ntdll, NtLockProductActivationKeys);
	}


}

VOID 
_stdcall 
onLogon(  IN PVOID arg  )
{
	sethooks();
}


#ifdef _DEBUG1
int _tmain(int argc, _TCHAR* argv[])


{
	sethooks();
	dllRegUnreg(FALSE) ;
	dllRegUnreg(TRUE) ;

	return 0;
}


#else
BOOL WINAPI _DllMainCRTStartup(
        HANDLE  hinstDLL,
        DWORD   fdwReason,
        LPVOID  lpvReserved
        )


{

	g_hinstDll = hinstDLL;
	return TRUE;
}
#endif