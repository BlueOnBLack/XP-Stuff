AntiWPA 3 source info 
=====================

Usage:
	regsvr32 antiwpa.dll

Building:
	
	Microsoft Platform SDK
		http://www.microsoft.com/downloads/details.aspx?familyid=EBA0128F-A770-45F1-86F3-7AB010B398A3
		(395 MB)
		Subdir _Build\
		adjust SDK path in env.cmd
	 	i386.cmd builds for x86, amd64.cmd - for amd64 platform
	
	Visual Studio 2003:
		open SRC\_VS.Net\hook.vcproj
		To debug set in project properties Debug
			Command: C:\WINDOWS\system32\rundll32.exe
			Arg: "$(TargetPath)",onLogon
		and set Breakpoint(F9) on line main.c!sethooks()
		
		
	Windows 2003 DDK:
		Needs to be order at M$ :(

	
	(Visual C++ Toolkit 2003
		http://www.microsoft.com/downloads/details.aspx?FamilyID=272be09d-40bb-49fd-9cb0-4bfa122fa91b
		(32MB)
		Adjust files in Build\
		run i386.cmd

		Note: Will only work to build 32-Bit version
				You will need to get advapi32.lib user32.lib shlwapi.lib shell32.lib elsewhere
				or see notes on how to compile without these libs
	)
		


How to live debug winlogon.exe:

run mstsc /v 127.0.0.1 on WinXP Pro applied TSFree patch it remove 1 user TS-Limitation.
Attach ya debugger (ollydebug or the in Visual Studio one-[ctrl+alt+p] ) to the new 
create winlogon.exe / set ya breakpoints. Then enter user and password in loginscreen...
 Hurry you've 90 sec until TSsession timeout occurs and winlogon is killed.
OR
HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Terminal Server
IdleWinStationPoolCount=1 
(reboot) Now it's attach to 'idle' winlogon.exe... This time you don't have to
worry with the 90 sec timeout.


Tech details:
	Based on Antiwpa-User32-implementation.
	dll is loaded using winlogon notification package registry entries
	(HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon\Notify)
	- same as reset5 etc...
	Instead of patching any files only dll functions are hooked in memory
	(ZwLockProductActivationKeys in ntdll and GetSystemMetrics in user32)
	This should be version-independent (length-disassembler is used to hook functions)
	parts of GNU binutils used for amd64 disassembler (libopcodes-lde)

WlpNotifyStrings
0	$   	"Logon"
1	$+4 	"Logoff"
2	$+8 	"Startup"
3	$+C 	"Shutdown"
4	$+10	"StartScreenSaver"
5	$+14	"StopScreenSaver"
6	$+18	"Lock"
7	$+1C	"Unlock"
8	$+20	"StartShell"
9	$+24	"PostShell"
a	$+28	"Disconnect"
b	$+2C	"Reconnect"

{Login via RemoteDesktop...}

Mainloop 
	->Startup	(Blank screen)

	Call LogonAttempt
	(Loading User configurations)

	->Logon
	Call WPA_Check_Caller
		->StartShell <= if WPA_succeed

	->PostShell <= if WPA_succeed
	CALL BlockWaitForUserAction
		{Session is running...}
		{Disconnect Session}
		...Winlogon!Dialogboxhandle
			->Reconnect
		
		{Reconnect Session}			
		...Winlogon!Dialogboxhandle
			->Reconnect
			
			
		{Logoff executed...}
	Call Logoff
		->Logoff

winlogon.GetScreenSaverInfo
	HKEY_CURRENT_USER\Control Panel\Desktop\
		ScreenSaverIsSecure==1?
		ScreenSaveActive
		NoAutoReturnToWelcome
		SCRNSAVE.EXE	default "SCRNSAVE.scr"

	"Software\Policies\Microsoft\Windows\Control Panel\Desktop
		ScreenSaverIsSecure==1?
		ScreenSaveActive
		SCRNSAVE.EXE=="(NONE)"?
		
	"SCRNSAVE.scr /s"
		




                                                

Logon			[REG_SZ] DllAPI for logon events , for example: "WLEventLogon".
Logoff		[REG_SZ] DllAPI for logoff events, for example: "WLEventLogoff".

Startup		[REG_SZ] DllAPI for system startup events, for example: "WLEventStartup".
Shutdown		[REG_SZ] DllAPI for shutdown     , for example: "WLEventShutdown".

StartScreenSaver[REG_SZ] DllAPI for ssaver   , for example: "WLEventStartScreenSaver".
StopScreenSaver[REG_SZ] DllAPI for screen saver stop events, for example: "WLEventStopScreenSaver".

Lock			[REG_SZ] DllAPI for desktop lock , for example: "WLEventLock".
Unlock		[REG_SZ] DllAPI for desktop unlock events, for example: "WLEventUnlock".

StartShell	[REG_SZ] DllAPI for shell start  , for example: "WLEventStartShell".
				A shell start event occurs after the user has logged on but before the desktop appears.
				It differs from the logon event in that the user's security context has been established,
				and resources such as network connections are available.



Asynchronous = 1 [REG_DWORD] means, Winlogon calls the package functions in a separate thread. And waits 5 sec till execution finishes
DllName		[REG_EXPAND_SZ] Name of the DLL that implements the notification package, for example: "Notify.dll".
Impersonate = 1 [REG_DWORD] means that Winlogon should impersonate the security context of the logged-on user when it calls the notification package functions.

SAS = secure attention sequence 
	A key sequence that begins the process of logging on or off. The default sequence is CTRL+ALT+DEL. 


Some more Notes:

hhm right for only the source it's hard to see what it does. I also found C is also not nice to read. But never the less the sourcecode can tell you exactly what it does. - But not the why :(                                                                                                                    
Well of course the [i]should[/i] be some more comments.  Be it is as it is. :twisted:                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                                                                                   
For exploring start like it starts:                                                                                                                                                                                                                                                                                
main.c->DllMainCRTStartup                                                                                                                                                                                                                                                                                          
main.c ->onLogon                                                                                                                                                                                                                                                                                                   
...from the outside (Dll-Exports) to the inside                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                   
To see all more about selfinstallation look at                                                                                                                                                                                                                                                                     
regunreg.c->DllRegisterServer                                                                                                                                                                                                                                                                                      
regunreg.c->DllUnregisterServer                                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                   
It will be really helpfull to get it compiled so you can step though the sourcecode with the a source debugger. Don't be to curious and step into each function. You might lose the line of thought. Guess from the name what it does - and what it contribute to the algorithm and only step in if it's necessary.
                                                                                                                                                                                                                                                                                                                   
That's how it works in generally:                                                                                                                                                                                                                                                                                  
Its hooks / redirects these system functioncalls (=API's) of winlogon.exe:                                                                                                                                                                                                                                         
NtLockProductActivationKeys                                                                                                                                                                                                                                                                                        
GetSystemMetrics                                                                                                                                                                                                                                                                                                   
 to itself (Antiwpa.dll) first and these decides to call the real API and/or to manipulate the result (return value).                                                                                                                                                                                              
                                                                                                                                                                                                                                                                                                                   
These Hooks are set when antiwpa.dll was loaded into the target process (winlogon) and calls Antiwpa!onlogon.                                                                                                                                                                                                      
The import Hooking proc of antiwpa 3.4 works as the following:                                                                                                                                                                                                                                                     
Antiwpa!onlogon locates the adress of the PE-exe-header (= base adress                                                                                                                                                                                                                                             
-almostly 0x40 000) of the process it was loaded. Thought the PE-exe-header it locates the importable in memory.                                                                                                                                                                                                   
It scan importtable for NtLockProductActivationKeys & GetSystemMetrics copy/send its 'original startaddress' to antiwpa and overwrites it with an adress which points inside/to AntiWPA!myNtLockProductActivationKeys and                                                                                          
AntiWPA!NtLockProductActivationKeys. That's it now Antiwpa.dll has control over these API.                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                                                   
Note: Antiwpa 3.3 uses so called exporthooks - it didn't modifies the importtable instead to overwrite the start of ntdll!NtLockProductActivationKeys with jmp AntiWPA!myNtLockProductActivationKeys to gain control over the API...

---

Shlwapi.lib is only needed for the install & deinstall function which is 
DllRegisterServer DllUnregisterServer. The mainpart 'onlogon' works also without Shlwapi.dll. If don't have Shlwapi.lib use the force switch '/f' in the the to linker argument part of cl.exe. 

Seems you're using Visual C++ Toolkit 2003. Well that's at least better than nothing. You can compile it without advapi32.lib user32.lib shlwapi.lib shell32.lib if you use the force switch and remove that line: 
main.c if(!GetSystemMetrics(SM_CLEANBOOT)) {. 
But again don't use install & deinstall function if you do so. Install normal antiwpa(to let it do the registry settings) and replace system32\antiwpa.dll with your new one. 

---

For public release build avoid that antiwpa.dll uses msvcr71.dll imports. Because
msvcr71.dll is not included in the windows XP installation package. Add ntdll.lib to the 
Libpath when compiling - so AntiWPA.dll will import the necessary API from there.

-----

I tooked importshook code of 'HookImportedFunctionByName.c' from the MSDN bugslayer codeexample.
For understanding to debug step it though in VS and watch the vars.
To do so a usually change compile properties from dll to exe and ran it in VS C++.
Change to compile to debug and have a look at main.c
#ifdef _DEBUG1
int _tmain(int argc, _TCHAR* argv[])
change it to #ifdef _DEBUG, delete/uncomment entire #ifdef or get _tmain to run elsewhere. It will catch user32!GetSystemMetrics of msdev.exe but who cares - for seeing how the hook is applied it doesn't matter.

I put some notes I made by my self when learning more about exe-import on:
[url]http://free.pages.at/antiwpa/src/doc/EXE-%20ImportTable.htm[/url]
To quick summorise it: The importstable consists actually of 3 table:
The IMPORT_DESCRIPTOR
  containing a list of all dll's and a reference to FirstThunk table

The FirstThunk
  containing a list of all API-names of a dll
  during load windows loader replace them by memaddresse

The OriginalFirstThunk
  only a backup of FirstThunk that is not touched(modified) by windows loader

After finding it's ways thought pointer to the untouched OriginalFirstThunk HookImportedFunctionsByName() tries to find the right API-entry by STRingCoMPare. It switchs over to FirstThunk and returns the value there to the caller of HookImportedFunctionsByName() and then overwrites it with the memaddress provided to HookImportedFunctionsByName (=hooked function for ex myGetSystemMetrics...). That's how the hook gets installed :wink:.

