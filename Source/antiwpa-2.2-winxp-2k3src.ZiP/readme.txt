-======================================-
        The Windows 2003 & XP
   Anti Product Activation Crack 2.2
-======================================-

The crack will patch some bytes in your
winlogon.exe and totally disable the
Windows Product Activation Check.

Tested with winlogon.exe build:
  Windows XP  2600.5512 (SP3 RCx) 
  Windows XP  2600.3264 (SP3 RC1)
  Windows XP  2600.2180 (SP2 RTM)
  Windows XP  2600.1106 (SP1)
  Windows XP  2600.0    (Retail)
  Windows 2K3 3790.0    (Retail)
  Windows 2K3 3790.1218 (8.7.2004)
  Windows Longhorn 4008 or 4015(not tested by myself)

This version uses a generic patch engine
which supports all current version of Windows
and hopefully all future ones. :)


The Options
===========

1. Read all about the options.
2. Don't change anything you without a reason.


 * Apply OOBE Fix
    This applies the Out Of Box Experience ->OOBE Patch
    which removes the 'Activate Windows' link from the
    start menu and makes the Activating Windows Dialog
    saying 'Already Activated'

    Note: This is more a cosmetically fix and really not
          needed for the patch to work properly.


 * Apply WPA Fix
    This removes the WPA-Check in Winlogon.exe.
    If you want to get rid of the Windows Activation
    this MUST be Enabled !
    Disable this if you just want to undo the OOBE-Fix.

    Note: However you can use this program also to
          decrypt and unprotect other MS-Files
          like DPCDLL.dll or LICDLL.DLL. So if you
          do so disable this option.

 * Replace Msoobe.exe with AntiWPA
 	 Replaces the "Let's Activate" program with the AntiWPA.
 	 So incase you installed some servicepack which removes 
 	 the patch and you are force to activate now simply click
 	 'Yes' and instead of the activation program the patch is
 	 started...
 	 Incase you click on the "Activate Windows"-Link in the
 	 start menu both the patcher and the normal 'normal' 
 	 activation program will be started.
 
<<< End Of 'Normal' user options !


 * Remove selfcheck blocks
    Note by pressing the 'Apply' button the self checks are ALWAYS
    disable via 'correcting' the pointer.

    This option will additionally overwrite the self check block
    calls in the program code with the value 90 (NOP=No OPeration)
    and will improve the readability of disassembly.
    
    'NopOut completely' filles entired block with 0x90 Nop
    	If your disassembler has the option to hide 'fillcode' like nop
    	this is the best choice
    		
    'Add short Jmp at the beginning to jump over the Nop's'
      If you like it simple choose this
      
     'Fill with 'long' asmcodes with don't take that much 
     lines in the disassembling than the nop's '
       The nop's will be relaced with the 10 Byte command
       mov [ffffffff],ffffffff. Of course these command are not
       executed and skipped with a short jump at the beginning.
       

    Note: This option is absolutely not necessary for the patch to work.


 * Remove crypt blocks
    This will decrypt the crypted program parts of the input file and
    write them back to into the exe and do some other fixes to keep the
    File executable. If you want to disassemble the file enable this one.

    Note: This option is absolutely not necessary for the patch to work.
          Currently this option is unreliable so keep in mind that in some
          causes it will corrupt/crash the exe. 
          (After using this my winlogon need the about 4 manually crashfixes.)


 * Debug: Save decrypted code to *.bin
    Writes each decrypted program parts into a file with the
    address as filename looking like this: 2C18D.bin, 3678B.bin...


 * Debug: Save decrypted code to exe
    Writes each decrypted program parts back into the file.
    If the option 'Remove crypt blocks' is not check just the decrypted
    RAW-Output is written into the exe. (After you enable this you
    have to right click on 'Apply/Browse' and open the file you want
    to decrypt)

    Note: This option is dangerous!
          Without having 'Remove crypt blocks' option enabled this will
          make crash the input file crash for sure.
          This option is absolutely not necessary for the patch to work.

 * Debug: Create MAP-File
	Creates a *.Map file that contains the StartOffsets of the crypted
	function. In Ollydbg you may load this file by godfather+'s MapConv
	plugin. So after loading the map into olly you may set a breakpoint
	to each of this crypted function's that are probably more 'interesting'
	than the others. ;)


 * Debug: Verbose Output
    Output Debug information
    This may be helpful to identify some problems.


The Buttons
===========

[Apply/Browse]

Left click applied the selected Tasks in options.
Note: The selfchecks of winlogon.exe are always disabled
		even if no options are selected.

Right click to change the path to winlogon.
	Good for to apply the patch other network
	to some other OS or for preparing a winlogon.exe
	before creating a windows Setup CD

NEW: Open a file by Drop'n'Drag
	You can also open a file by dragin it into the
	Antiwpa2 Window.


[Restore]

Undo the selected tasks in options.
	So if you want to undo only the 'MSOOBE-Fix'
	uncheck all other options expect 'MSOOBE-Fix'
	and then press the restore button


The CommandLine
===============

Run it like this:
WPA_Kill.exe Winlogon.exe

Or use UNQUOTED Filename like this:
WPA_Kill.exe C:\My path\Winlogon.exe



==================================================
	F A Q  - Frequently Asked Questions
==================================================

????????????????????????????????????????????????????????????????????????????????
	Will there be a 64-Bit Version of Antiwpa2
????????????????????????????????????????????????????????????????????????????????
No I'm not planning to do this since it will be much work.
You can use Antiwpa3 which also supports X64 and IA64 systems.
Or changing your to cooperated by exchanging these
Files: Oembios.*, dpcdll.dll, pidgen.dll them setting a VLK CDKEY
like V2C47-MK7JD-3R89F-D2KXW-VPK3J.

There maybe patched winlogon.exe for this purpose but major thing
is not to patch the WPA-check, but to get the selfchecks all over
winlogon disabled so you can applied.
(If the selfcheck fails winlogon will crash & exit 
 and without a running winlogon the watchdog-thread of csrss.exe 
 will create a nasty STOP-blahblah bluescreen.)


????????????????????????????????????????????????????????????????????????????????
	After I have installed a Service pack the Activation Reminder
	counting down the days is show again.
????????????????????????????????????????????????????????????????????????????????

You must reapply the patch every time after you installed a servicepack and
everything will be fine :)

Note: The Patch don�t �activated� Windows it only removes the check in
winlogon.exe
which test if windows is activated or if it�s still in the evaluation period
and force you to logoff if something is wrong.

When you install a servicepack winlogon.exe is normally overwritten by a new
Not patched Version. So you need reapply the patch.
Usually the servicepack reset the trial counter so it will restart at 30 days.


????????????????????????????????????????????????????????????????????????????????
	I can�t start patch because my evaluation period expired and
	Now I�m unable to login.
????????????????????????????????????????????????????????????????????????????????

You can still login in safe mode even if your evaluation period expired.
Press F8 right after the Bios boot screen and select Safe Mode
(Without Network support) menu now windows should boot in safe mode and you can
Login and apply the Anti-WPA-Patch.

Note: Since no Network support is available in safe mode no Internet or Network
Is available so it�s good to have the patch somewhere on the hard disk or on a
floppy disk�
If you select Safe Mode (with Network support) you are unable to login due to
Activation is necessary.


????????????????????????????????????????????????????????????????????????????????
   Well windows says that it was activated but when i restarted my pc,
   a pop up message appears and says that i have only 25 days to activate windows.
????????????????????????????????????????????????????????????????????????????????    
This means the patch is not active.
Or only the oobe-fix was applied but not there was an error applying 
the real patch -> see FAQ: know problem asian system

After you applied the patch start it again -now it should say 'Already applied'.
If not start it again and check is there are any errors in the log output.
If there are no errors, but you still don't get 'Patch already applied' disable the windows systemfile protection manually.

Background:
Everytime you login the activation is done and the days remaining are written to
HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\WPAEvents\[OOBETimer].
(Note: they're only written not read from there so changing this has absolutely
 no effect on activation.) Also a special value means Activation done.(->xp-wpa-crack.txt). msoobe.exe and msinfo32.exe only use this value to determinate whether Windows is activated or not. So right after the Patch everything looks fine the Activation Dialog shows 'Already Activated'. But if you login the OOBETimer value is 'updated' -since the real check is still active- and trial countdown continues...



????????????????????????????????????????????????????????????????????????????????
	I want to change my CD-Key - but msoobe.exe also says
	'Already Activated and don't show the Activation Dialog
????????????????????????????????????????????????????????????????????????????????

Enable option 'Apply OOBE Fix' and
Disable option 'Apply &WPA Fix' -to keep the WPA-Patch active-
then click on the 'Restore Backup' Button

PREVIOUS VERSIONS:
Start regedit and go to
HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\WPAEvents\[OOBETimer]
Edit this and set Last Byte to FF.
Start this -if the Activation are delete- to show the Activation dialog:
%SYSTEMROOT%\system32\oobe\msoobe.exe /A



????????????????????????????????????????????????????????????????????????????????
	Is it possible to integrate WPA_KILL.EXE in the WinXP setup-routine?
	I have a WinXP pro setup CD (sp2 integrated).
????????????????????????????????????????????????????????????????????????????????

Integrating the AntiWPA Patch in the Windows Setup:

1. Extract [WindowsSetupDir]\i386\winlogon.ex_ to a temporary Dir.
   (Winrar or winace will do the job - or rename it to winlogon.cab and
   double-click on it - to use the build-in WindowsCabExtract)

2. Apply the WPA Crack to the file.
   Right click on 'Apply/Browse' and choose the file.
   (To unlock all buttons of the WPA-Patch right click on 'Quit')

3. Repack winlogon.exe an put it back in the installation folder
   Use Winace (and choose MS-Cab as compression method) and name
   the packed cab-file winlogon.ex_.
   Or use the makecab.exe(included in Windows XP) start cmd.exe in the dir
   winlogon.exe is in and Enter:

   makecab winlogon.exe

After that you will get winlogon.ex_ as output.

PREVIOUS VERSIONS:
In previous versions the PE Checksum of the file wasn't updated by the patch.
This caused setup to reject winlogon.exe during installation.
But this has been fixed in this version.


Manually OOBE_Fix for WindowsSetup
----------------------------------
Since I see people integrating the patched winlogon.exe into windows setup are
perfectionist here's a hint how to may you get rid of the activationlinks in
the startmenu (-untested-):
Ok unpack and edit syssetup.inf

1. search for
	[StartMenuCommon]
	and delete this to avoid the activate link in START
	%oobe_desc% = oobe\msoobe.exe,"%%SYSTEMROOT%%\system32\oobe\msoobe.exe
/A",,0,"@%SystemRoot%\system32\oobe\msoobe.exe,-2001","%SystemRoot%\system32\oob
e\msoobe.exe",2000
	(btw you can also delete this unless %windowscatalog% link section if you
like)

2.	In SystemTools it's the same
	[SystemTools]
	%oobe_desc% = oobe\msoobe.ex...

Just for better understanding the inf-file format at the end is defined what the
variable "oobe_desc" is:
oobe_desc = "Windows aktivieren"
This was were I first stepped when I searched for "Windows aktivieren" in
C:\windows
The second was to look for oobe_desc...

No-CDKey-Patch for WindowsSetup
-------------------------------
- Since I got some positiv feedback about this I decided to publish this.
  But so far I'ven't test it myself-

This will make the WindowsSetup to accept any -even a blank- CDKey
Get "http://antiwpa.tk/Other/cracked pidgen for setup.rar"
Pack it pidgen.dll with cab-pack to pidgen.dl_ as decribed above
and put it in the I386 setupdir.
That's it.



????????????????????????????????????????????????????????????????????????????????
	What changes does this patch to my System and how to undo it?
????????????????????????????????????????????????????????????????????????????????

1. It modifies c:\WINDOWS\system32\Winlogon.exe and creates a
   backup named Winlogon.bak
   UNDO: Rename Winlogon.exe -> Winlogon.OUT
         Rename Winlogon.bak -> Winlogon.exe
         After Reboot you will be able to delete Winlogon.OUT if you like


2. The RegistryValue
   HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\WPAEvents\[OOBETimer]
   is set to a fixed value as it is activated.
   UNDO: Edit this with Regedit and set Last Byte to FF.
         This will 'DeActivate' Windows

   Note: Normally this value is written (not read!) by winlogon.exe on
         every start up just as information for MSOOBE.
         This value has no effect on the real Activation.


3. The 'Activate Windows' Link from the Startmenu is remove
   UNDO: Start\Execute:
   rundll32 setupapi,InstallHinfSection RESTORE_OOBE_ACTIVATE 132 syssetup.inf


4. 'Replace Msoobe.exe with AntiWPA' renames your original msoobe.exe
	to msoobe.com and copies it self to <windows>\system32\oobe\msoobe.exe


Other Changes:
HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Setup
"SourcePath" and "ServicePackSourcePath" will be temporary delete during the
patch
and (if nothing really bad happens) restored if it's finished.



????????????????????????????????????????????????????????????????????????????????
	How to set another path to Winlogon.exe?
????????????????????????????????????????????????????????????????????????????????

Right click on the 'Apply/Browse' button.
If the Patch is already and the 'Apply/Browse' button is greyed out
Right click on the 'Quit' button to force unlock all buttons.

Note: You can also use the Windows Anti WPA Patch to de-protect
      (Remove SelfCheckBlock SCB) from other protected
      Microsoft exe and dll's:
      For ex: licdll.dll, DPCDLL.dll or Windows PLUS! Pack Executables
      Of course the WPA-Patch is skipped in this case.


????????????????????????????????????????????????????????????????????????????????
	The Patch doesn't work after I rebooted, the WPA Reminder pops up again.
	Also during the Patch the Windows Systemfile Protection Dialogbox didn't
	come up.
????????????????????????????????????????????????????????????????????????????????

Maybe the Patch was undone by the Windows File Protection.
To check if the patch is still active start the Windows Anti WPA Patch again and
check if it says 'Patch already applied'.



????????????????????????????????????????????????????????????????????????????????
	How to disable this damn Windows File Protection(WFP)?
????????????????????????????????????????????????????????????????????????????????

There is no really official way to disable this

This is an undocumented setting worked for recent windows versions:
HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon
SFCDisable=0xffffff9d

BUT: It was removed in Windows 2000 Service Pack 2 and in Windows XP!
When you restart your computer, the System event log will contain Event ID
64032, "Windows File Protection is not active on this system."

SFCDisable (REG_DWORD)
0 = enabled (default - WinXP Professional)
1 = disabled, prompt at boot to re-enable - Require a kernel debugger to be
hooked up or this will be ignored!
2 = disabled at next boot only, no prompt to re-enable - Require a kernel
debugger to be hooked up or this will be ignored!
4 = enabled, with popups disabled (default - for all Server Windows)
More about this and how to re-enable the 'SFCDisable=0xffffff9d-setting'
 -> http://www.collakesoftware.com/aboutwfp.htm
To make this more flexible here is a search'n'replace patch:
(Rename sfc_os.dll to sfc_os.OUT; copy sfc_os.OUT to sfc_os.dll)
Open sfc_os.dll in a hex editor
Search for  : 83 f8 9D 75 08 33 C0 40
Replace with: 83 f8 9D EB 08 33 C0 40

So this is where it comes from:
         A1 D8E1C376     MOV     EAX, [SFCDisable]
Patch- > 83F8 9D         CMP     EAX, -63					;-63 => 0xffffff9d !
Search > 75 08           JNZ     SHORT Don't_Set_SFCDisable_=_1
Data   > 33C0            XOR     EAX, EAX
       > 40              INC     EAX
         A3 D8E1C376     MOV     [SFCDisable], EAX
:Don't_Set_SFCDisable

Btw this fragment is the reason 0xffffff9d don't work anymore - so
Nop Out (=overwrite with 0x90) that bastard

-> You can download a Patch that does that change from antiwpa.tk /others!


Well I found a real simple way to disable this for sure:
Rename c:\WINDOWS\system32\sfc.dll to sfc-OUT.dll to something else
After Reboot the WFP is disabled.
BUT I advice to rename sfc-OUT.dll back to sfc.dll soon because I notice
that you can't install any new hardware device driver because syssetup.dll
statically imports sfc.dll and fail to load if sfc.dll is not found.



????????????????????????????????????????????????????????????????????????????????
	The Patcher doesn�t find any offset. / Know problem on Asian systems.
????????????????????????????????????????????????????????????????????????????????

WPA_KILL.EXE currently don't work with Asian Systems (Taiwan, Japan...) with
DBCS (Double Character Set)
enabled. 
An error (unintented behaviour) in the string handling functions  
of the Patch program causes problems on DBCS systems. 
But the Patch logic/Algo also works for this systems. 
 


Workaround:  


Workaround:
If you have such systems disable DBCS.
Or copy your winlogon.exe to an none DBCS system apply the patch to your winlogon
and copy the patched winlogon.exe back in your system. 
-> Pay attention that the Windows System File Protection don't restore your original 
winlogon!(see FAQ: How to disable the Windows File Protection ?)
Have a look into system events logs or compare both file dates 
to see if WFP has restored winlogon.exe


As far as I found out the Test Version function does not work properly and you
get 'unknown Version'. A Workaround that might work is to use the offset locator to detect/set the right offset manually.
(Hint: Compare the detected offset with the known-offset-list)
The problem is related to some improper char handling and/or comparing inside
FrmMain.Test() i.e FileStream::FixedString()
Everyone how has an Asian System and MSOffice(Note: VBA is always also installed
together with MSO) or Visual Basic 6 is welcome to invite me to a remote
Session. - so I can examine and fix that problem - Please send me an email...
And of course you�re also welcome to fix it your self:
antiwpa.tk
\other\cracknfo\problem-onasian-systems.rar
\SRC\antiwpa-2.0.0-winxp-2k3-src.zip



????????????????????????????????????????????????????????????????????????????????
	How you access/modify the winlogon.exe file while it is running ?
	I only saw you are using standart API calls but I must have missed
	something...
????????????????????????????????????????????????????????????????????????????????


How to modify a file (like winlogon.exe) while it is in use:

1.Rename winlogon.exe -> winlogon.bak
  That's the most important thing about that. You can't delete or
  modify a file that's in use, but you can RENAME it! (under Win9x
  this don't work. Rename the dir containing the file instead...)

2.Copy winlogon.bak -> winlogon.exe

3.Now you can edit winlogon.exe. Of course you can't delete (or
  modify) winlogon.bak as long as it is in use.
  But you surely want to keep an backup of it, don't you?

Oh I almost forgot to mention an other annoy thing:
>The Windows system File Protection (WFP) <
When renaming/modifying winlogon.exe as described above the WFP will immediately
restore the original file without any warning(There will just be an entry in the
event logger - but how cares about this).
To avoid this:
* Delete all files in C:\windows\system32\dllcache\*.*
* Rename the path were installed your last Service pack or the path to
the windows installation file to something else like
'D:\installs\WinXP_SP2' -> 'D:\installs\WinXP_SP2.out'
So the WFP won't file them to restore

Well the WPA-Patch doesn't rename your Windows installation path it deletes
temporary the path to this in you registry and restores it after the patch
(actually after you clicked on the OK button of the messagebox).
These Registry paths are:
HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Setup
"SourcePath"= "D:\installs\WinXP_CD"
"ServicePackSourcePath" ="D:\installs\WinXP_SP2"

----------------------------------------------------------
Just a hint to see if the patch worked without to Reboot:

1.Apply the patch
2.Logon as an other user
(But don't log of - choose change/disconnect user)
3.When you login just see if the patch works...
... or if not this damn
'You haven't activated your Windows yet...' message

(4.If you logoff the first user now 'winlogon.bak' is no long in use
and you can delete/modify it)

Ah and to get a better overview about the processes which are running on your
machine use this: http://www.sysinternals.com/ntw2k/freeware/procexp.shtml
And next time you can't delete a files use 'search handle' and enter the
filename then close the handle(=file) or kill the process...



????????????????????????????????????????????????????????????????????????????????
	Does the AntiWPA Crack make winlogon.exe unstable?
????????????????????????????????????????????????????????????????????????????????


Since the WPA 1.6.2 disables all anti crack self checks in winlogon.exe it may
execute some msec faster :)
The patch simply makes winlogon.exe to skip the function which will do the
WPA-Check( update of WPA trial counter) and block any login if the result is 'negative'.

From 'outside' this windows is simple not activated but as long your using a
valid CDKEY Windows update will work and is not affected by the WPA-Patch
> does the patch make winlogon.exe unstable?
No. If it is applied correctly winlogon.exe will not become unstable/crash.
(The only time winlogon.exe becomes unstable is after appling wpa-kill 1.1 to
WinXP SP1 - but this bug was fix in version 1.2...)
Of course with the wrong offset in offset locator you can make winlogon.exe
unstable/crash or by killing the patcher during the patch is applied.



????????????????????????????????????????????????????????????????????????????????
PREVIOUS VERSIONS:
	I got 'ERROR: Unknown Version of winlogon.exe'.
	Can you include this version in your WPA-Patcher ?
????????????????????????????????????????????????????????????????????????????????

Well please try the offset locator button to patch this new Version. Since
Version 1.4 I added a heuristic search for offset locator which should find the
right offset by default and highlight it.
So -after you read the warning- just double click on the highlight Offset on the
List to set this as new patch-Offset.

If this is not a Beta or Release Candidate Version send me your -unpatched-
Winlogon.exe by email and add if the default offset (found by the for offset
locator) works.




????????????????????????????????????????????????????????????????????????????????
PREVIOUS VERSIONS:
	The patch don't work - if i click on the 'Activate Windows' link in the
	start menu, it says Windows isn't activated and that there are only xx days
left.
????????????????????????????????????????????????????????????????????????????????

This patch didn't stop the trial counter nor will it 'Activate' your Windows.

The WPA-Patch fixes the condition jump which decides whether windows was started
in safe mode
and the activation check should be skipped or if it was started in normal mode
and it should be done.
So in short it will make winlogon.exe to skip the is-Windows-activated check
when you logon.

To see if the patch work wait about one minute after you logon -
if the Activation reminder balloon in the tray bar DON'T pop up - the patch IS
working.
Some other things to see that it works
The messagebox that reminders you to active if there are only 5 days left and
The messagebox that says you're not allowed to logon until you active will be
away.

So patching msobmain.dll just to make it say it's activated is only additional
overheat and
also may cause some problems. Maybe if you want to change your CDKey and you
don't reach the CDKEY change dialog because it says already activated...
Ok what I need to do is to include some FAQ-info text in the next version about
that issue.
Maybe I will add a "Let's Activate Windows" force true patch if there is such a
big need for this
I mean if this will make someone sleeps better at night - is enough for a good
reason.




-------------------------------------------------
History
2.2.0 Nov'08
	Added open file by commandline and Drag'n'Drop
	Clearer logOutput for restoreFile
	SFC_Block and the 'Wait for Windows File Protection' only when really need
	Changed UpdateUrl to http://antiwpa11.tk
	documented 'Debug: Create MAP-File' option in readme
	
2.1.7 Jul'08
	Slight changes to avoid detection + deleting by Norton Antivirus 2008

2.1.6 Jan'08
	Tested with XP SP3

2.1.4 jun'05
	Add 64-bit detection to PE-File open function

2.1.3 May'05
	Minorbugfix: warningmessage when enable menu 'Debug: save to exe' now appears at the right time

2.1.2 May'05
	Bugfix for 'Remove crypt blocks' (Tail stub is not overwritten anymore)
	URL-Updated to http:\\Antiwpa3.tk

2.1.0 Mar'05
	'Replace Msoobe.exe with AntiWPA' option added
	Optionsdialog for 'Remove selfcheck blocks' added

2.0.2 Feb'05
	Updates in readme

2.0.1 Nov'04
	'Remove crypt Blocks' option didn't calculate correct
	fixup address for WinLH winlogon.exe fixed
	Updates in readme

2.0.0 Oct'04
  Patcher is now able to scan the crypt code parts
  and to finds the right patch offset automatically
  (no Version and offset locator hassle anymore)
  PE Checksum of patched file is updated
  Added Restore Backup Function
  Added menu bar with Options

1.7.x  Oct'04
  *Internal Beta Versions*

1.6.2 Sep'04
  Added MSOOBE Activation Fix
  Added Readme.txt

1.6 Aug'04
  Added support for WinXP SP2 2180

1.5 Jul'04
  BugFix: Changes set by offsetlocator were not written to disk

1.4 Jun'04
  Added support for WinXP SP2 RC1 2142
  Added heuristic search for offset locator

1.3 Jun'04
  Added support for WinXP SP2 RC1 2120
  smaller changes

1.2 Apr'04
  Patch recoded in Visual Basic 6
  Added generic check block disabler
  Added offset locator to support unknown versions
  Added support for WinXP SP2 Beta and Win2K3
  Improved Windows File Protection support

1.1 Nov'03
  BugFix: SP1 crashed when returning from standby
  Improved Windows File Protection support

1.0 Sep'03
  First release using the apatch-engine


<http:\\Antiwpa11.tk>				crackware2k@freenet.de
